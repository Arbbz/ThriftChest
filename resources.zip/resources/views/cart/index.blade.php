@extends('layout.main')

@section('container')
<section class="container my-5">
    <h2 class="mb-4">Keranjang Belanja</h2>
    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if(empty($cart))
        <p class="text-center">Keranjang belanja Anda kosong.</p>
    @else
        <table class="table table-bordered mt-5">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Gambar</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($cart as $index => $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item['name_product'] }}</td>
                        <td>
                            @if(isset($item['image']))
                                <img src="{{ asset('storage/'.$item['image']) }}" class="img-fluid" style="max-width: 100px;">
                            @endif
                        </td>
                        <td>Rp. {{ number_format($item['harga'], 2) }}</td>
                        <td>
                            <form action="/cart/{{ $index }}/delete" method="post">
                                @csrf
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif

    <div class="text-center mt-5">
        <a href="/" class="btn btn-warning mb-4 mr-2 text-white"><i data-feather="shopping-cart"></i> Lanjutkan Belanja</a>
        <a href="/checkout" class="btn btn-danger mb-4 mr-2">Checkout</a>
    </div>
</section>
@endsection
