@extends('layout.main')

@section('container')
    <section class="container my-5">
        <h2 class="mb-4">Status</h2>
        @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
         @endif
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Total Price</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach($transactions as $transaction)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $transaction->name }}</td>
                        <td>{{ $transaction->address }}</td>
                        <td>{{ $transaction->phone }}</td>
                        <td>{{ $transaction->total_price }}</td>
                        <td>{{ $transaction->status }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </section>
@endsection
