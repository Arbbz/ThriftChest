@extends('layout.main')

@section('container')
<section class="container my-5">
    <h2 class="mb-4">Checkout</h2>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-8 mb-3">
                        <h4>Order Summary</h4>
                        <table class="table ">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($cart as $item)
                                <tr>
                                    <td>{{ $item['name_product'] }}</td>
                                    <td>Rp. {{ number_format($item['harga'], 2) }}</td>
                                    <td>{{ $item['quantity'] }}</td>
                                    <td>Rp. {{ number_format($item['harga'] * $item['quantity'], 2) }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <b>Total Price: Rp. {{ number_format($totalPrice, 2) }}</b>
                    </div>


                <form action="{{ route('checkout.store') }}" method="post" >
                    @csrf
                    <h4>Shipping Details</h4>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="name" class="form-control" required value="{{ auth()->user()->name }}">
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" id="address" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" name="phone" id="phone" class="form-control" required>
                    </div>
                    <div class="form-group mt-3">
                        <button type="submit" class="btn btn-primary">Complete Order</button>
                    </div>
                </form>
            </div>
        </div>

    </section>
@endsection
