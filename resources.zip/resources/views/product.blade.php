@extends('layout.main')

@section('container')

<section class="hero-wrap hero-wrap-2" style="background-image: url('foto/sepatuatas.webp');" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center mt-3">
            <div class="col-md-9 mb-5 text-center">
                <form action="/product" class="d-flex align-items-center w-100 mb-3 mt-2">
                    <div class="input-group">
                        {{-- <h2 class="me-3">
                            <a href="/categories" class="text-decoration-none">Categories</a>
                        </h2> --}}
                        <input type="text" name="search" class="form-control bg-light border-2 small"
                               placeholder="Search for..." value="{{ request('search') }}">
                        <button class="btn btn-dark ms-2" type="submit">
                            <i data-feather="search"></i>
                        </button>
                    </div>
                </form>
                <h2 class="mb-0 bread">Produk</h2>
            </div>
        </div>


    </div>
</section>

<section class="ftco-section">
    <div class="container">
        @if($products->isEmpty())
            <div class="alert alert-warning" role="alert">
                Product not found.
            </div>
        @else
        <div class="row">
            @foreach ($products as $product)
            <div class="col-md-4 d-flex mt-3 mb-3">
                <div class="card" style="width: 100%;">
                    <a href="/detail/{{ $product->id }}" class="d-flex flex-column align-items-center justify-content-center h-100 text-decoration-none img-hover">
                        <div class="img-container mt-1">
                            <img src="{{ asset('storage/'.$product->image) }}" class="card-img-top" alt="Image">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <span class="badge bg-primary">{{ $product->category->name }}</span>
                        <h5 class="card-title mt-2">{{ $product->name_product }}</h5>
                        <p class="card-text">Rp. {{ $product->harga }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        @endif
    </div>
</section>
@endsection
