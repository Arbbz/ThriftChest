@extends('layout.main')

@section('container')

<section class="hero-wrap hero-wrap-2">
	<div class="container">
		<div class="row  slider-text align-items-end justify-content-center">
			<div class="col-md-9 mb-5 text-center mt-5">
				<h2 class="mb-0 bread">Detail Produk</h2>
			</div>
		</div>
	</div>
</section>

<section class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 mb-5 d-flex justify-content-center">
            <a href="{{ asset('storage/'.$products->image) }}" class="image-popup prod-img-bg">
                <img src="{{ asset('storage/'.$products->image) }}" class="img-fluid">
            </a>
        </div>
        <div class="col-md-6 p-5 product-details pl-md-5 ftco-animate text-left d-flex flex-column justify-content-center">
            <h3>{{$products->name_product }}</h3>
            <p class="price"><span>Rp. {{$products->harga}}</span></p>
            <p>Deskripsi produk</p>
            <form action="/cart/add/{{ $products->id }}" method="post" class="d-block">
                @csrf
                <button class="btn btn-success" type="submit"><i data-feather="shopping-cart"></i> Beli Produk</button>
            </form>
        </div>
    </div>
</section>




@endsection
