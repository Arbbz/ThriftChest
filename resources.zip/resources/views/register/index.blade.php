@extends('layout.main')
@section('container')
<section class="vh-100" style="background-image: url('img/bg3.jpg'); background-size: 300vh 150vh;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class=" col-lg-6 col-xl-8">
        <div class="card shadow-2-strong" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <h3 class="mb-5">Registrasi</h3>

            <form action="/register" method="POST">
              @csrf
              <div class="form-outline mb-4">

                <input type="text" name="name" class="form-control form-control-lg mb-1 @error('name') is-invalid @enderror" placeholder="Nama" value="{{old('name')}}" autocomplete="off"/>
                @error('name')
                <div class="invalid-feedback ">
                    {{ $message }}
                </div>
                @enderror

                <input type="email" name="email" class="form-control form-control-lg mb-1 @error('email') is-invalid @enderror" value="{{old('email')}}" placeholder="Email" />
                @error('email')
                <div class="invalid-feedback ">
                    {{ $message }}
                </div>
                @enderror

                <input type="password" name="password" class="form-control form-control-lg mb-1 @error('password') is-invalid @enderror" placeholder="Password"/>
                @error('password')
                <div class="invalid-feedback ">
                    {{ $message }}
                </div>
                @enderror
              </div>

              <button class="btn btn-primary btn-lg btn-block" type="submit">Register</button>
            </form>

            <hr class="my-4">

            <small>Sudah punya akun? <a href="/login">Login now</a></small>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection

