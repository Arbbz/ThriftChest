@extends('dashboard.layout.main')

@section('container')
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard |, {{ auth()->user()->name }}</h1>
</div>
@if(session()->has('success'))
<div class="alert alert-success" role="alert">
    {{ session('success') }}
</div>
@endif
<div class="table-responsive">
    <a href="/dashboard/category/create" class="btn btn-primary mb-3"><span data-feather=""></span>Add New Category</a>
        <table id="tabelmenu" class="table table-bordered table-striped table-hover">
            <thead>
                <tr class="bg-info text-light">
                    <th>No</th>
                    <th>Nama Category</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($categories as $category)
                <tr >
                    <td>{{ $loop->iteration }}</td>
                    <td >{{ $category->name }}</td>
                    <td>
                        <form action="/dashboard/category/{{$category->id}}" method="POST" class="d-inline ">
                            @method('delete')
                            @csrf
                            <button type="submit" class="badge bg-danger text-light border-0">
                                <span data-feather="trash"></span>
                            </button>
                        </form>

                    </td>
                </tr>
                @endforeach
            </tbody>
            {{-- @foreach ($categories as $category)
         <option value="{{$category->name}}">{{$category->name}}</option>
         @endforeach --}}
        </table>
    </div>
@endsection
