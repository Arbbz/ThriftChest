@extends('dashboard.layout.main')

@section('container')
<div class="d-sm-flex align-items-center justify-content-between flex-wrap flex-md-nonwrap mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add New Category</h1>
</div>

<div class="col-lg-8">
<form method="POST" action="/dashboard/category">
    @csrf
    <div class="form-group">
        <label>Nama Category</label>
        <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" placeholder="Nama Category" value="{{ old('name') }}">
        @error('name')
        <div class="invalid-feedback">
            {{ $message }}
        </div>
        @enderror
    </div>

    <div class="form-group">
        <label>slug</label>
        <input type="text" name="slug" class="form-control" value="{{ old('slug') }}">
    </div>

  <button type="submit" class="btn btn-primary">Add Category</button>
</form>
</div>

@endsection
