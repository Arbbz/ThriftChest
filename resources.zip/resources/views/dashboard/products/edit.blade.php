@extends('dashboard.layout.main')

@section('container')
<div class="d-sm-flex align-items-center justify-content-between flex-wrap flex-md-nonwrap mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Product</h1>
</div>

<div class="col-lg-8">
<form method="POST" action="/dashboard/products/{{$product->id}}" enctype="multipart/form-data" class="mb-5">
    @method('put')
    @csrf
  <div class="form-group">
    <label>Nama Product</label>
    <input type="text" name="name_product" class="form-control @error('name_product') is-invalid @enderror" placeholder="Nama Product" value="{{old('name_product', $product->name_product)}}">

    @error('name_product')
    <div class="invalid-feedback">
        {{ $message }}
    </div>
    @enderror
</div>

  <div class="form-group">
    <label>Jenis Product</label>
    <select class="custom-select" name="category_id" value="{{old('category_name', $product->name_product)}}">
    <option selected>Select Jenis Produk</option>
    @foreach ($categories as $category)
    @if(old('category_id', $product->category_id) == $category->id)
        <option value="{{$category->id}}" selected>{{$category->name}}</option>
    @else
        <option value="{{$category->id}}">{{$category->name}}</option>
    @endif
        @endforeach
    </select>

  </div>

  <div class="form-group">
    <label>Size</label>
    <select class="custom-select" name="size">
        <option selected>{{old('size', $product->size)}}</option>
        <option value="S">S</option>
        <option value="M">M</option>
        <option value="XL">XL</option>
        <option value="XLL">XLL</option>
    </select>
  </div>

    <div class="form-group">
        <label>Harga</label>
        <input type="number" name="harga" class="form-control" value="{{ old('harga', $product->harga) }}">
    </div>

    <div class="form-group">
        <label>Colors</label>
        <input type="text" name="color" class="form-control" value="{{ old('color', $product->color)}}">
    </div>

    <div class="form-group">
        <label class="form-label" for="image">Upload Images</label>
        <input type="hidden" name="oldImg" value="{{$product->image}}">
        @if ($product->image)
            <img src="{{asset('storage/'.$product->image)}}" class="img-preview img-fluid d-block  col-sm-5">
        @else
            <img class="img-preview img-fluid">
        @endif
        <input type="file" @error('image') is-invalid @enderror class="form-control" id="image" name="image" onchange="previewImage()">

        @error('image')
        <div class="invalid-feedback">
            {{ $message }}
        </div>
        @enderror
    </div>

  <button type="submit" class="btn btn-primary">Update Product</button>
</form>
</div>

@endsection
