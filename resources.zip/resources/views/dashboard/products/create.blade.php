@extends('dashboard.layout.main')

@section('container')
<div class="d-sm-flex align-items-center justify-content-between flex-wrap flex-md-nonwrap mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add New Product</h1>
</div>

<div class="col-lg-8">
<form method="POST" action="/dashboard/products" enctype="multipart/form-data">
    @csrf
  <div class="form-group">
    <label>Nama Product</label>
    <input type="text" name="name_product" class="form-control @error('name_product') is-invalid @enderror" placeholder="Nama Product" value="{{ old('name_product') }}">
    @error('name_product')
    <div class="invalid-feedback">
        {{ $message }}
    </div>
    @enderror

</div>

  <div class="form-group">
    <label>Jenis Product</label>
    <select class="custom-select" name="category_id">
    <option selected>Select Jenis Produk</option>
    @foreach ($categories as $category)
        <option value="{{$category->id}}">{{$category->name}}</option>
        @endforeach
    </select>

  </div>

  <div class="form-group">
    <label>Size</label>
    <select class="custom-select" name="size">
        <option selected>Select Sized</option>
        <option value="S">S</option>
        <option value="M">M</option>
        <option value="XL">XL</option>
        <option value="XLL">XLL</option>
    </select>
  </div>

  <div class="form-group">
    <label>Harga</label>
    <input type="number" name="harga" class="form-control" value="{{ old('harga') }}">
  </div>

  <div class="form-group">
    <label>Colors</label>
    <input type="text" name="color" class="form-control" value="{{ old('color') }}">
  </div>

  <div class="form-group">
    <label class="form-label" for="image">Upload Images</label>
    <input type="file" class="form-control @error('image') is-invalid @enderror" id="image" name="image">
    <img class="img-preview img-fluid">
    @error('image')
    <div class="invalid-feedback">
        {{ $message }}
    </div>
    @enderror
  </div>

  <button type="submit" class="btn btn-primary">Add Product</button>
</form>
</div>

<script>
    function previewImage(){
    const image = document.querySelector('#image');
    const imgPreview = document.querySelector('.img-preview');

    imgPreview.style.display = 'block';
    const oFreader = new FileReader();
    oFreader.readAsDataURL(image.file[0]);

    oFreader.onload = function(oFREvent){
        imgPreview.src = oFREvent.tager.result;
    }


    }
</script>
@endsection
