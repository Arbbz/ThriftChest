@extends('dashboard.layout.main')

@section('container')
    <section class="container my-5">
        <h2 class="mb-4">Transaction Details</h2>
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        <div>
            <p><strong>Name:</strong> {{ $transaction->name }}</p>
            <p><strong>Address:</strong> {{ $transaction->address }}</p>
            <p><strong>Phone:</strong> {{ $transaction->phone }}</p>
            <p><strong>Total Price:</strong> {{ $transaction->total_price }}</p>
            <p><strong>Status:</strong> {{ $transaction->status }}</p>
        </div>
        <form action="{{ route('transactions.update', $transaction->id) }}" method="post">
            @csrf
            @method('PATCH')
            <div class="form-group">
                <label for="status">Status</label>
                <select name="status" id="status" class="form-control">
                    <option value="pending" {{ $transaction->status == 'pending' ? 'selected' : '' }}>Pending</option>
                    <option value="confirmed" {{ $transaction->status == 'confirmed' ? 'selected' : '' }}>Confirmed</option>
                    <option value="shipped" {{ $transaction->status == 'shipped' ? 'selected' : '' }}>Shipped</option>
                    <option value="delivered" {{ $transaction->status == 'delivered' ? 'selected' : '' }}>Delivered</option>
                    <option value="cancelled" {{ $transaction->status == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                </select>
            </div>
            <div class="form-group mt-3">
                <button type="submit" class="btn btn-primary">Update Status</button>
            </div>
        </form>
    </section>
@endsection
