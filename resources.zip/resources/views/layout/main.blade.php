<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thrift | {{ $title }}</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('icon.png') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="/style.css">

    <script src="https://unpkg.com/feather-icons"></script>

  </head>

  <body class="d-flex flex-column min-vh-100">
  <div id="wrapper" class="flex-grow-1">
    <div id="content-wrapper" class="d-flex flex-column flex-grow-1">
      <div id="content">
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
         @endif

        @include('layout.header')

        <main>
          @yield('container')
        </main>

      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="bg-dark text-white p-4 text-center">
    <p>Jl. Menteng Raya No.29 1, RT.1/RW.10, Kb. Sirih, Kec. Menteng, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10340</p>
    <h5>Contact Us</h5>
    <p><i data-feather="mail"></i> Email: ThriftChest.id</p>
    <p><i data-feather="phone"></i> Phone: +62 85777434741</p>
    <p><i data-feather="message-square"></i> Whatsapp: 0857-7742-3741</p>
    <hr class="bg-light">
    <p class="text-center">&copy; 2023 Your Company. All rights reserved.</p>
  </footer>

  {{-- script --}}
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <script>feather.replace() </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
      crossorigin="anonymous"></script>
  <script src="/sb-admin-2.js"></script>
</body>
</html>

