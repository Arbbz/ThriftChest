<div class="wrap">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-12">
        </div>
      </div>
    </div>
  </div>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="ftco-navbar" style="background-color: red;">
    <div class="container">
      <a class="navbar-brand text-white" href="index.php">
        <img src="https://img.freepik.com/premium-vector/realistic-open-chest-vintage-old-treasure-wooden-box-pirate-dover-with-golden-glowing-inside_341509-1854.jpg?w=740"
        width="30px" style="border-radius: 10px;">
        &nbsp; Thrift Chest<span class="">&nbsp;</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fa fa-list"></i>
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item active"><a href="/" class="nav-link text-light">Home</a></li>
            <li class="nav-item active"><a href="/product" class="nav-link text-light">Produk</a></li>
            @auth
            <li class="nav-item active"><a href="/cart" class="nav-link text-light">Keranjang</a></li>
            <li class="nav-item active"><a href="/status" class="nav-link text-light">My Order</a></li>
            @endauth

            @guest
            <li class="nav-item active"><a href="/login" class="nav-link text-light">Login</a></li>
            @endguest
            <li class="nav-item active">
                @if(Auth::check() && Auth::user()->level === 1)
                    <a href="/dashboard" class="nav-link text-light">Administration</a>
                @endif
            </li>

            @auth
                <!-- Header Markup -->
            <li class="nav-item active dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Welcome back, {{ auth()->user()->name }}
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li>
                        <form action="/logout" method="POST" class="px-3">
                            @csrf
                            <button type="submit" class="btn w-100 text-left">
                                <span data-feather="log-out"></span>
                                <span class="logout-text">Logout</span>
                            </button>
                        </form>

                    </li>
                </ul>
            </li>
            @endauth
        </ul>
    </div>
    </div>
  </nav>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
