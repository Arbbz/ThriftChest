@extends('layout.main')
@section('container')


<section class="vh-100">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card shadow-2-strong" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">
            @if(session()->has('status'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              {{ session('status') }}
            </div>
            @endif

            @if(session()->has('loginError'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              {{ session('loginError') }}
            </div>
            @endif

            <h3 class="mb-5">Login</h3>
            <form action="/login" method="post">
            @csrf
              <div data-mdb-input-init class="form-outline">
                <input type="name" name="name" class="form-control form-control-lg mb-4" placeholder="Username" autocomplete="off" required/>
                <input type="password" name="password" class="form-control form-control-lg mb-4" placeholder="Password"/>
              </div>
              <button data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-lg btn-block" type="submit">Login</button>

            </form>
            <hr class="my-4">

            <small>Belum punya akun? <a href="/register">Register now</a></small>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection

