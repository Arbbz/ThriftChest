@extends('layout.main')

@section('container')
<!-- Hero Section -->
<div class="hero-wrap" style="background-image: url('/img/bg2.jpg'); background-size: cover; background-position: center center; width: 99.1vw; height: 100vh; padding: 0; margin: 0;" data-stellar-background-ratio="0.5">
    <div class="d-flex justify-content-center align-items-center" style="height: 100%;">
        <div class="text-center">
            <h1 class="mb-4" style="color: white; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);">Selamat Datang Di <span>Thrift Chest.</span></h1>
            @auth
            <h1 class="nav-item active text-light" style="text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);">Welcome back, {{ auth()->user()->name }}</h1>
            @endauth
            <p><a href="/product" class="btn btn-danger py-2 px-4">Produk Kami</a></p>
        </div>
    </div>
</div>

<section class="py-5 bg-danger">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-md-4 d-flex">
                <div class="intro d-lg-flex w-100">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <i data-feather="headphones"></i>
                    </div>
                    <div class="text pl-3">
                        <h2>Layanan 24 Jam</h2>
                        <p>Melayani Dengan Integritas Dan Pelayanan Yang Terpadu</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 d-flex">
                <div class="intro d-lg-flex w-100">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <i data-feather="dollar-sign"></i>
                    </div>
                    <div class="text pl-3">
                        <h2>Harga Worth It</h2>
                        <p>Kami menjual produk dengan harga paling murah</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 d-flex">
                <div class="intro d-lg-flex w-100">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <i data-feather="shopping-bag"></i>
                    </div>
                    <div class="text pl-3">
                        <h2>Barang Original</h2>
                        <p>Produk yang kami jual ialah produk original</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Us Section -->
<section class="py-5">
	<div class="container">
		<div class="row">
			<div class="col-md-6 d-flex justify-content-center align-items-center">
				<img src="/img/treasure.png" width="100%" style="border-radius: 10px">
			</div>
			<div class="col-md-6 pl-md-5 py-5">
				<div class="heading-section">
					<h3 class="mt-4">Tentang kami</h3>
					<p>Di tengah hiruk pikuk kehidupan perkotaan, terdapat sebuah toko baju thrift yang benar-benar istimewa. Dikelilingi oleh aura nostalgia, toko ini adalah surga bagi para pencinta gaya unik dan klasik. Namun, keistimewaan toko ini tidak hanya terletak pada koleksi barang-barangnya.</p>
					<p>Dengan harga yang terjangkau, setiap kunjungan ke toko ini adalah kesempatan untuk menemukan harta karun dan merasakan kegembiraan memperoleh barang-barang yang unik dan berharga. Sebagai destinasi favorit bagi para pencinta mode yang mencari lebih dari sekadar pakaian, toko baju thrift ini telah menjadi bagian penting dari komunitas fashion yang bersemangat dan beragam.</p>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Products Section -->
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center pb-5">
			<div class="col-md-7 text-center">
				<h2>Produk Kami</h2>
			</div>
		</div>

        <div class="row">
            @foreach ($products as $product)
            <div class="col-md-4 d-flex">
                <div class="card " style="width: 100%;">
                    <a href="#" class="d-flex flex-column align-items-center justify-content-center h-100 text-decoration-none img-hover">
                        <div class="img-container mt-1">
                            <img src="{{ asset('storage/'.$product->image) }}" class="card-img-top" alt="Image">
                        </div>
                    </a>
                        {{-- deskripsi --}}
                    <div class="card-body text-center">
                        <span class="badge bg-primary">{{ $product->category->name }}</span>
                        <h5 class="card-title">{{ $product->name_product }}</h5>
                        <span class="card-text">Rp. {{ $product->harga }}</span>
                    </div>
                </div>
            </div>
            @endforeach
        </div>


		<div class="row justify-content-center mt-5">
			<div class="col-md-4">
				<a href="/product" class="btn btn-danger d-block">Lihat Semua Produk <i data-feather="arrow-right"></i></a>
			</div>
		</div>
	</div>
</section>

@endsection
